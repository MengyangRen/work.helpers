<?php
/**
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 *   
 *   合作商范围组件
 *   
 * @author  v.r
 * @package task.services 
 * 
 * 注: 辅助方法为私有方法 命名以下滑线开头
 *

 * 
 */

class hzsAreaComponent
{

    /**
     * 合作商定义的
     * 省code
     * 省id,
     * 
     * @var array
     */
  public static $map = array(
    
    //新疆
    'xjhx'=>array(
      'as'=>'65',
      'province_id'=>3393,
    ),

    //贵州
    'gzhx'=>array(
      'as'=>'52',
      'province_id'=>2726,
    ),

    //甘肃
    'gshx'=>array(
      'as'=>'62'
      'province_id'=>3194,

    ),
    
    //黑龙江
    'hljhx'=>array(
      'as'=>'23'
      'province_id'=>706,
     ),
    
    //内蒙
    'nmhx'=>array(
      'as'=>'15'
      'province_id'=>375,
     ),
    
    //吉林
    'glhx'=>array(
      'as'=>'62'
      'province_id'=>628,
     ),

    //大连
    'dlhx'=>array(
      'single_city'=>1,  //单列市
      'as'=>'21'
      'province_id'=>499,
      'city_id'=>515,
     ),
  );

}