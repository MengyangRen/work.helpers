<?php
/**
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 *   
 *   创建客户Json组件
 *   
 * @author  v.r
 * @package task.services 
 * 
 * 注: 辅助方法为私有方法 命名以下滑线开头
 * 
 */
define('GENERAL_TAXPAYER',0); //一般纳税人
define('GENERAL_TAXPAYER_AS','一般纳税人');

//-----------------------------------------------
define('SMALL_SCALE_TAXPAYER',1); //小规模纳税人
define('SMALL_SCALE_TAXPAYER_AS','小规模纳税人');

//----------------------------------------
define('POINT_DOWN_DROOM',2);
define('POINT_DOWN_DROOM_AS','点下户');
define('NON_TAXPAYER',3); //非纳税人

class createCustomComponent
{

  
  /**
   * 
   *  创建客户_json
   *  
   * @param array  item     crm用户数据项
   * @return void
   * 
   */
  public static function makeJson($item = NULL,$objs = NULL) {
    $item = createCustomComponent::rehabItemData(
        $item,
        $objs
    );
    return Util::jsonEncode(array(
        'user'=>array(
          'sex'=>3,
          'phone'=>$item['MOBILE'],
          'true_name'=>$item['CONTACT'],
          'nick_name'=>'',
        ),
        'company'=>array(
          'company_type'=>$item['company_type'],
          'tel_phone'=>$item['TEL'],
          'address'=>$item['ADDR'],
          'province_id'=>$item['province_id'],
          'city_id'=>$item['city_id'],
          'zone_id'=>$item['zone_id'],
          'level'=>0,
          'tax_number'=>$item['CUST_TAX_CODE'],
          'master_slave'=>$item['BILLING_MACHINE_NO'],
          'legal_person_name'=>$item['LEGAL_PERSON'],
          'legal_person_phone'=>$item['MOBILE'],
          'company_name'=>$item['cust_name'],
          'charge_end_date'=>$item['CHARGE_END_DATE']
    )));
    
  }

  /**
   * 
   *  修复数据
   *  
   * @param array item 邮局编码
   * @param array objs 对象
   *         
   * @return void
   * 
   */
  private static function rehabItemData($item = NULL,$objs = NULL) {
      $area = createCustomComponent::makeCompanyArea(
        $item['TAX_AUTHORITY_CODE'],
        $item['CUST_TAX_CODE'],
        $objs,
        $item['org']
      );
      
      $item['province_id'] = $area['province_id'];
      $item['city_id'] = $area['city_id'];
      $item['zone_id'] = $area['zone_id'];
      
      $item['company_type'] = createCustomComponent::makeCompanyType($item['CUST_SCALE']);
      //服务费过期处理
      $item['CHARGE_END_DATE'] = Util::formatDate($item['CHARGE_END_DATE']);

      if ($item['TEL'] == '无')
          $item['TEL'] = '';


      return $item;
    
  }
  
  /**
   * 
   *  生成区域信息
   *  
   * @param int tax_bureau 邮局编码
   * @param int tax_number 税号
   * @param array          模型对象 
   * @param org            
   * @return 
   * 
   * 
   */
  private static function makeCompanyArea($tax_bureau = NULL,$tax_number = NULL, $objs = NULL, $org = NULL) {
    $arr = array();

    /**
     * 情况1.
     * 
     * 税局号不为空，不等于 "无"
     *  exit;
     *  
     */                     
    if (!empty($tax_bureau) && $tax_bureau != "无" ) 
       $arr =  createCustomComponent::getAreaIdByTaxBureau(
          $tax_bureau,
          $objs
        );

    if (!empty($arr['province_id'])  && 
        !empty($arr['city_id'])      && 
        !empty($arr['zone_id'])) 
      return $arr;


    /**
     * 情况2
     *
     * 基于税局号进行解析后，查询为空时，
     * 
     */
    $hzs = $objs['hzsModel']->getHzsAreasBySign($org);
    $tarr = createCustomComponent::getAreaIdByTax(
       $tax_number,
       $objs
    );
    /**
     * 情况3
     *
     * 合作商区域与税号所在的省一致的情况下
     * 
     */
    if ($tarr['province_id'] == $hzs['province_id']) {
       return $tarr;
    } else {
       $arr['province_id'] = $hzs['province_id'];
       $arr['city_id'] = 0;
       $arr['zone_id'] = 0;
    }
   
    return $arr;
  
  }

  /**
   * 
   *  通过税局编码获取省市区id
   * 
   * @param string tax_bureau 邮局编码
   * @return void
   * 
   */
  public static function getAreaIdByTaxBureau($tax_bureau = NULL,$objs = NULL) {
    $arr = array('province_id'=>0,'city_id'=>0,'zone_id'=>0);
    $temp = Util::analyseProvinceCodeByTaxBureau($tax_bureau);

    if (!empty($temp['province']['code'])) {
        $p = $objs['regionModel']->getIdByZcode($temp['province']['code'],0);
        $arr['province_id'] = $p['id'];
    }
        
    if (!empty($temp['city']['code'])) {
      $c = $objs['regionModel']->getIdByZcode($temp['city']['code'],1);
      $arr['city_id'] = $c['id'];

    }

    if (!empty($temp['zone']['code'])) {
        $z = $objs['regionModel']->getIdByZcode($temp['zone']['code'],2);
        $arr['zone_id'] = $z['id'];
    }

    return $arr;
  }

  /**
   * 
   *  通过税局编码获取省市区id
   * 
   * @param string tax_bureau 邮局编码
   * @return void
   * 
   */
  public static function getAreaIdByTax($tax_number = NULL,$objs = NULL) {
    $arr = array('province_id'=>0,'city_id'=>0,'zone_id'=>0);
    $temp = Util::analyseRegionCodeByTax($tax_number);


    if (!empty($temp['province']['code'])) {
        $p = $objs['regionModel']->getIdByZcode($temp['province']['code'],0);
        $arr['province_id'] = $p['id'];
    }
        
    if (!empty($temp['city']['code'])) {
      $c = $objs['regionModel']->getIdByZcode($temp['city']['code'],1);
      $arr['city_id'] = $c['id'];

    }

    if (!empty($temp['zone']['code'])) {
        $z = $objs['regionModel']->getIdByZcode($temp['zone']['code'],2);
        $arr['zone_id'] = $z['id'];
    }
    return $arr;
  }

    /**
     * 
     *  动态生成更新的字段
     * 
     * @param  array item  crm系统用户字段项
     * @return void
     *
     * 公司名称
     * 公司类型(一般纳税人 ，小规模，大规模)
     * 行业类型
     * 联系人电话
     * 联系名字
     * 座机
     * 分机号
     * 
     */
    public static function makeUpFieldArr($item = NULL,$objs = NULL) {

      $area = createCustomComponent::makeCompanyArea(
        $item['TAX_AUTHORITY_CODE'],
        $item['CUST_TAX_CODE'],
        $objs,
        $item['org']
      );

      $fieldArr = array(); 
      
      if (!empty($item['cust_name']))
          $fieldArr['company_name'] = $item['cust_name'];
      
      if (!empty($item['CUST_SCALE']))
          $fieldArr['company_type'] = createCustomComponent::makeCompanyType($item['CUST_SCALE']);
      
      if (!empty($item['INDUSTRY_NAME']))
          $fieldArr['trade_id'] =  '404';
      
      if (!empty($item['MOBILE'])) 
          $fieldArr['legal_person_phone'] = $item['MOBILE'];
      
      if (!empty($item['LEGAL_PERSON'])) 
          $fieldArr['legal_person_name'] = $item['LEGAL_PERSON'];
      
      if (!empty($item['TEL']) && $item['TEL'] != "无")
         $fieldArr['tel_phone'] = $item['TEL'];
      
      if (!empty($item['BILLING_MACHINE_NO']))
         $fieldArr['master_slave'] = $item['BILLING_MACHINE_NO'];
      
      if (!empty($item['BILLING_MACHINE_NO']))
         $fieldArr['master_slave'] = $item['BILLING_MACHINE_NO'];

      if (!empty($item['ADDR'])) 
         $fieldArr['address'] = $item['ADDR'];

      if (empty($area['province_id']))
          $area['province_id'] = 0;

      if (empty($area['city_id']))
          $area['city_id'] = 0;

      if (empty($area['zone_id']))
           $area['zone_id'] = 0;


      $fieldArr['province_id'] = $area['province_id'];
      $fieldArr['city_id'] = $area['city_id'];
      $fieldArr['zone_id'] = $area['zone_id'];
      return $fieldArr;
    }

    /**
     * 
     *  生成公司类型
     * 
     * @param string type 公司类型
     * @return void
     * 
     */
    public static function makeCompanyType($type = NULL) {
      switch ($type) {
        case GENERAL_TAXPAYER_AS:
          return GENERAL_TAXPAYER;
          # code...
        break;
        case SMALL_SCALE_TAXPAYER_AS:
          return SMALL_SCALE_TAXPAYER;
          # code...
        break;
        case POINT_DOWN_DROOM_AS:
          return POINT_DOWN_DROOM;
          # code...
        break;
        default:
          # code...
          return NON_TAXPAYER;
        break;
      }
    }
}