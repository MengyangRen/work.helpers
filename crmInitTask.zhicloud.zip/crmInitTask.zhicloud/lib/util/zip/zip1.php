<?php
$zip = new ZipArchive;  

if ($zip->open('20180507162149.zip') === TRUE) {  
    $zip->setPassword("eu8dsae734!uf");//设置压缩包的密码
    $zip->extractTo("C:\workspace\PHPenv\svr\crmTaskServer.zhicloud\lib\util\zip");//解压文件到/tmp/zip/文件夹下面
    $zip->close();  
    echo 'ok';  
} else {  
    echo 'failed';  
} 