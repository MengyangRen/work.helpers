<?php
/**
 * Created by Sawyer's Raytheon Notebook.
 * User: Sawyer Yang
 * Date: 2018/1/25
 * Time: 11:16
 */

require_once dirname(__DIR__) . DIRECTORY_SEPARATOR . 'autoload.php';

use Qiniu\Auth;
use Qiniu\Storage\UploadManager;

class uploadFile
{

    protected $filePath;

    protected $bucket = 'zhicloud-download';

    /**
     * @return mixed
     */
    public function getFilePath()
    {
        return $this->filePath;
    }

    public function __construct($filePath, $bucket = '')
    {
        if (!empty($bucket)) {
            $this->bucket = $bucket;
        }
        $this->filePath = $filePath;
    }

    public function upload($uploadFileName = '')
    {
        $accessKey = \Qiniu\Config::ACCESS_KEY;
        $secretKey = \Qiniu\Config::SECRET_KEY;
        $auth = new Auth($accessKey, $secretKey);
        // 空间名  http://developer.qiniu.com/docs/v6/api/overview/concepts.html#bucket
        $bucket = $this->bucket;

        try {
            // 生成上传Token
            $token = $auth->uploadToken($bucket);
            // 构建 UploadManager 对象
            FILE_EXIST: // 如果报错，文件存在就重新来
            $uploadMgr = new UploadManager();
            $key = $uploadFileName ? $uploadFileName : md5(mt_rand(1, 5000) . time() . mt_rand(50, 5000));
            $result = $uploadMgr->putFile($token, $key, $this->filePath);
            if ($result[0] == null) {
                $Response = $result[1]->getResponse();
                if ($Response->statusCode == 614) {
                    // 生成覆盖上传Token errorCode=614代表目标文件已存在
                    $token = $auth->uploadToken($bucket, $key);
                    GOTO FILE_EXIST;
                }
            }
            if ($result[1] == null) {
                return '/' . $key;
            }
        } catch (Exception $e) {
            throw new Exception($e->getMessage(), -777);
        }
    }
}


