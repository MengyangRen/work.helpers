<?php

namespace PhpZip\Exception;

/**
 * Runtime exception.
 *
 * @author Ne-Lexa alexey@nelexa.ru
 * @license MIT
 */
class RuntimeException extends ZipException
{
}
