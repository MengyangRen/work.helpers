<?php
 

$xml = '/data/crm/20180524164037566.xml';

//$xml = 'site_1.xml';
$myxml = simplexml_load_file($xml);
print_r($myxml);
        
    
        print_r(xmlToArray($myxml));
    
    function xmlToArray($xml){
       $arr_xml = (array)$xml;
       foreach($arr_xml as $key=>$item){
           if(is_object($item) || is_array($item)){
               $arr_xml[$key] = xmlToArray($item);
           }
       }
       return $arr_xml;
   }


 //include_once "./FluidXml.php";

 /* 
 include_once "./xml.php";

 $file = '/data/crm/20180524164037566.xml';

$xml = file_get_contents($file);
print strlen($xml);

$xml = new xml($xml);

print count($xml);
*/
