<?php

/**
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 * 
 *  地区模型
 *     
 * @author  v.r
 * @package task.services 
 * 
 * 注: 辅助方法为私有方法 命名以下滑线开头
 * 
 */


class regionModel 
{
	
	private $table = 'zhiCloudCommon.region';
	private $model = NULL;
	private $useDb = 'zhiCloudCommon';

	public function __construct($uq = NULL) {
	    $this->model = Factory::NewDB(
			SERVER_CONFIG::$dbs[$this->useDb],
			$uq
		);
	}
	public function getIdByZcode($code = NULL,$type = 0) {
        //$sql = "SELECT id FROM ".$this->table. " WHERE  `code` = ". $code ." AND  `type` = ".$type;
        
		$sql = "SELECT id FROM ".$this->table. " WHERE  `code` = '". $code ."'";
		$result = $this->model->query($sql);
		$ret = $result->fetchall();
		return $ret[0];
	}


    /**
     * 
     *  更新合作商id
     *  
     * @param   mixed $increment default true, 
     * else full crawler
     *  getHzsIDBySign
     */
	public function upHzsID($uid = NULL ,$hid = NULL) {
		$sql = "UPDATE ".$this->table." SET hzs_id = '{$hid}'";
		$sql.= " WHERE id = '{$uid}'";
		return $this->model->query($sql);
	}

}