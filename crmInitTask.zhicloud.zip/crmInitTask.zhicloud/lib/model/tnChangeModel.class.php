<?php

/**
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 *   所用数据库相关模型
 * @author  v.r
 * @package task.services 
 * 
 * 注: 辅助方法为私有方法 命名以下滑线开头
 *
 *
 * CREATE TABLE `tn_changes` (
      `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
      `company_id` mediumint(8) unsigned NOT NULL COMMENT '公司id',
      `tax_number` char(30) COLLATE utf8_bin NOT NULL DEFAULT '' COMMENT '注册号或者纳税号',
      `created` datetime DEFAULT NULL COMMENT '创建时间',
      `modified` datetime DEFAULT NULL COMMENT '修改时间',
      PRIMARY KEY (`id`)
    ) ENGINE=InnoDB AUTO_INCREMENT=23673 DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='税号变更表';
 * 
 */


class tnChangeModel 
{

	private $table = 'zhiCloudCustoms.tn_changes';
	private $model = NULL;
	private $useDb = 'zhiCloudCustoms';

    public function __construct($uq = NULL) {
        $this->model = Factory::NewDB(
            SERVER_CONFIG::$dbs[$this->useDb],
            $uq
        );
    }
    
    /**
     * 
     * 更新用户发送应用的状态
     * @param   mixed $increment default true, else full crawler
     *  getWriteQueueFailedItems
     *  
     */
    public function save($tax_number = NULl,$id = NULL) {
        $sql = "INSERT INTO ".$this->table." (`company_id`, `tax_number`) VALUES ('".$id."','".$tax_number."')";
        print $sql;
        $use = "use ". $this->useDb;
        $this->model->query($use);
        return $this->model->query($sql);
    }
}

