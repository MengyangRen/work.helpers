<?php

/**
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 *   合作商模型
 *   
 * @author  v.r
 * @package task.services 
 * 
 * 注: 辅助方法为私有方法 命名以下滑线开头
 * 
 */


class cchModel 
{
	private $table = 'zhiCloudCustoms.custom_company_hzs';
	private $model = NULL;
	private $useDb = 'zhiCloudCustoms';

	public function __construct($uq = NULL) {
	    $this->model = Factory::NewDB(
			SERVER_CONFIG::$dbs[$this->useDb],
			$uq
		);
	}

    /**
     * 
     *  更新合作商id
     *  
     * @param   mixed $increment default true, 
     * else full crawler
     *  getHzsIDBySign
     */
	public function upHzsID($cid = NULL ,$hid = NULL) {
        $sql = "UPDATE ".$this->table." SET hzs_id = '{$hid}'";
        $sql.= "WHERE compan_id = '{$cid}'";
        return $this->model->query($sql);
	}

	/**
     * 
     *  获取该公司下的所有用户ID
     *  
     * @param   mixed $increment default true, 
     * else full crawler
     *  getHzsIDBySign
     */
	public function getCustomIds($company_id = NULl) {
		$sql = "SELECT custom_id FROM ".$this->table. " WHERE  `compan_id` = '". $company_id."'";
		$result = $this->model->query($sql);
		return $result->fetchall();
	}


}