<?php

/**
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 *   公司模型
 * @author  v.r
 * @package task.services 
 * 
 * 注: 辅助方法为私有方法 命名以下滑线开头
 * 
 */


class zhicloudCompanSrcModel 
{
	private $table = 'zhiCloudNetWorkSrc.zhicloud_compan_src_t';
	private $model = NULL;
	private $useDb = 'zhiCloudNetWorkSrc';

	public function __construct($uq = NULL) {
	    $this->model = Factory::NewDB(
			SERVER_CONFIG::$dbs[$this->useDb],
			$uq
		);
	}

	/**
     * 
     *  报错数据
     * @param   mixed $increment default true, else full crawler
     *  getWriteQueueFailedItems
     */
	public function save($data) {
		$sql = createSqlComponent::Insert($this->table,$data);
		return $this->model->query($sql);
	}
}