<?php
/**
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 *   测试服务
 * @author  v.r
 * @package task.services 
 * 
 * 注: 辅助方法为私有方法 命名以下滑线开头
 * 
 */
class initCustomSrcTask implements Itask
{
	

	/**
     *  运行
	 * @return mixed 
     */
	public static function run($srv, $task_id,$from_id,$data,$callback) {
		try {	

        	$data = Util::jsonDecode($data);
     		$taskData = (array) $data['condition'];

			$index = $data['num'];
			$items = $taskData['items'];
			$nowTaskUrl = $items[$index];



        	$maps = Util::getZipDataForQiniu(
			    QINIU_DOMAIN.$nowTaskUrl
			);

			$itemNum =  0;
            $len = count($maps);

            if (!$len)  
                return $callback(array('data' => array('success' => $len, 'fail' => 0),'type' => $data['type'], '_uq' => $data['_uq']));

		

			$objs = array(
			  'companysModel'=>Factory::model('companysModel'),
			  'hzsModel'=>Factory::model('hzsModel'),
			  'customsModel'=>Factory::model('customsModel'),
			  'cchModel'=>Factory::model('cchModel'),
			  'regionModel'=>Factory::model('regionModel'),
			  'tnChangeModel'=>Factory::model('tnChangeModel'),
			  'zhicloudCompanSrcModel'=>Factory::model('zhicloudCompanSrcModel')
			);

            $success = 0;
            $fail = 0;

			//从七牛获取资源数据。
			//获取资源进行入库
			
			do {

				$item = $maps[$itemNum];
				$item += array('org'=>$taskData['org']);

				$flag = $objs['zhicloudCompanSrcModel']->save(array(
				  'tax'=>$item['CUST_TAX_CODE'],
				  'type'=>4, //crm服务初始化的数据
				  'company_name'=>$item['cust_name'],
				  'tb_code'=>empty($item['TAX_AUTHORITY_CODE'])? '': $item['TAX_AUTHORITY_CODE'] ,
				  '_as'=>$item['org'],
				  '_md'=>createCustomComponent::makeJson($item,$objs)
				));

				if ($flag) 
				  $success +=1;
				else
				  $fail +=1;


			    $itemNum++;
			} while ($len > $itemNum);

			return $callback(
				array(
					 'data'=>array(
						'success'=>$success,
						'fail'=>$fail,
					  ),
					 'type' => $data['type'],
					 '_uq'=>$data['_uq']
				)
			);

		} catch (\Exception $e) {
		    var_dump($e->getMessage());
		    var_dump($e->getCode());
		}
	}

    /**
     *  汇总
	 * @return mixed 
     */
	public static function Finish($srv, $task_id,$element,$data,$callback) {
		$_uq = Util::jsonDecode($data)['_uq'];
        print PHP_EOL;
        print '-------------------初始化结果-----------------------------------';
        print PHP_EOL;
        print "\033[32;40m [编号] \033[0m".':'.Util::jsonDecode($data)['_uq'];
        print PHP_EOL;
        print "\033[32;40m [结果] \033[0m".':'.Util::jsonEncode($element);
        print PHP_EOL;
        print '-------------------初始化结果------------------------------------';
        print PHP_EOL;
	    return $callback($data);
	}
}
